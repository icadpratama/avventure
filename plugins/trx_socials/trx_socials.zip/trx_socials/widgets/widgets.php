<?php
/**
 * ThemeREX Socials: Widgets
 *
 * @package WordPress
 * @subpackage ThemeREX Socials
 * @since v1.0.0
 */

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) die( '-1' );


/* Widgets utilities
------------------------------------------------------------------------------------- */

// Prepare widgets args - substitute id and class in parameter 'before_widget'
if (!function_exists('trx_socials_prepare_widgets_args')) {
	function trx_socials_prepare_widgets_args($id, $class, $args=false) {
		if ($args === false) {
			global $TRX_SOCIALS_STORAGE;
			$args = $TRX_SOCIALS_STORAGE['widgets_args'];
		}
		if (!empty($args['before_widget'])) $args['before_widget'] = str_replace(array('%1$s', '%2$s'), array($id, $class), $args['before_widget']);
		return $args;
	}
}


// Widget class
//--------------------------------------------------------------------

if (!class_exists('TRX_Socials_Widget')) {
	class TRX_Socials_Widget extends WP_Widget {
		function __construct($class, $title, $params) {
			parent::__construct($class, $title, $params);
		}

		// Show one field in the widget's form
		function show_field($params=array()) {
			$params = array_merge(array(
										'type' => 'text',		// Field's type
										'name' => '',			// Field's name
										'title' => '',			// Title
										'description' => '',	// Description
										'class' => '',			// Additional classes
										'class_button' => '',	// Additional classes for button in mediamanager
										'multiple' => false,	// Allow select multiple images
										'rows' => 5,			// Number of rows in textarea
										'options' => array(),	// Options for select, checklist, radio, switch
										'params' => array(),	// Additional params for icons, etc.
										'label' => '',			// Alternative label for checkbox
										'value' => ''			// Field's value
										),
										$params);
			?><div class="widget_field_type_<?php echo esc_attr($params['type']);
					if (!empty($params['dir'])) echo ' widget_field_dir_'.esc_attr($params['dir']);
			?>"><?php
				if (!empty($params['title'])) {
					?><label class="widget_field_title"<?php if ($params['type']!='info') echo ' for="'.esc_attr($this->get_field_id($params['name'])).'"'; ?>><?php
						echo wp_kses_post($params['title']);
					?></label><?php
				}
				if (!empty($params['description'])) {
					?><div class="widget_field_description"><?php echo wp_kses_post($params['description']); ?></div>
					<?php
				}
				
				if ($params['type'] == 'select') {
					?><select id="<?php echo esc_attr($this->get_field_id($params['name'])); ?>"
							name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>"
							class="widgets_param_fullwidth<?php if (!empty($params['class'])) echo ' '.esc_attr($params['class']); ?>"><?php
					if (is_array($params['options']) && count($params['options']) > 0) {
						foreach ($params['options'] as $slug => $name) {
							echo '<option value="'.esc_attr($slug).'"'.($slug==$params['value'] ? ' selected="selected"' : '').'>'
									. esc_html($name)
								. '</option>';
						}
					}
					?></select><?php
	
				} else if (in_array($params['type'], array('radio', 'switch'))) {
					if (is_array($params['options']) && count($params['options']) > 0) {
						?><div class="widgets_param_box<?php
							if (!empty($params['class'])) echo ' class="'.esc_attr($params['class']).'"';
						?>"><?php
						foreach ($params['options'] as $slug => $name) {
							?><label><input type="radio"
										id="<?php echo esc_attr($this->get_field_id($params['name']).'_'.$slug); ?>"
										name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>"
										value="<?php echo esc_attr($slug); ?>"
										<?php if ($params['value']==$slug) echo ' checked="checked"'; ?> />
							<?php echo esc_html($name); ?></label> <?php
						}
						?></div><?php
					}

				} else if ($params['type'] == 'checkbox') {
					?><label<?php if (!empty($params['class'])) echo ' class="'.esc_attr($params['class']).'"'; ?>><?php
						?><input type="checkbox" id="<?php echo esc_attr($this->get_field_id($params['name'])); ?>" 
									name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>" 
									value="1" <?php echo (1==$params['value'] ? ' checked="checked"' : ''); ?> /><?php
							echo esc_html(!empty($params['label']) ? $params['label'] : $params['title']);
					?></label><?php

				} else if ($params['type'] == 'checklist') {
					?><span class="widgets_param_box<?php
									if (!empty($params['class'])) echo ' '.esc_attr($params['class']);
									?>"
							data-field_name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>[]">
						<?php 
						foreach ($params['options'] as $slug => $name) {
							?><label><input type="checkbox"
										value="<?php echo esc_attr($slug); ?>" 
										name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>[]"
										<?php if (strpos(','.$params['value'].',', ','.$slug.',')!==false) echo ' checked="checked"'; ?>><?php
								echo esc_html($name);
							?></label><?php
						}
					?></span><?php
	
				} else if ($params['type'] == 'color') {
					?><input type="text"
							id="<?php echo esc_attr($this->get_field_id($params['name'])); ?>" 
							name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>"
							value="<?php echo esc_attr($params['value']); ?>"
							class="trx_socials_color_selector<?php if (!empty($params['class'])) echo ' '.esc_attr($params['class']); ?>" /><?php
	
				} else if ($params['type'] == 'textarea') {
					?><textarea id="<?php echo esc_attr($this->get_field_id($params['name'])); ?>" 
							name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>"
							rows="<?php echo esc_attr($params['rows']); ?>"
							class="widgets_param_fullwidth<?php if (!empty($params['class'])) echo ' '.esc_attr($params['class']); ?>"><?php
								echo esc_html($params['value']);
					?></textarea><?php
	
				} else if ($params['type'] == 'text') {
					?><input type="text"
							id="<?php echo esc_attr($this->get_field_id($params['name'])); ?>" 
							name="<?php echo esc_attr($this->get_field_name($params['name'])); ?>"
							value="<?php echo esc_attr($params['value']); ?>"
							class="widgets_param_fullwidth<?php if (!empty($params['class'])) echo ' '.esc_attr($params['class']); ?>" /><?php
				}
				?>
			</div><?php
		}


		// Display widget's common params
		//---------------------------------------------------------
		
		// Show ID, Class
		function show_fields_id_param($instance, $group=false) {
			if ($group===false)
				$group = __('ID &amp; Class', 'trx_socials');
			if (!empty($group))
				$this->show_field(array('title' => $group,
										'type' => 'info'));
			
			$this->show_field(array('name' => 'id',
									'title' => __('Element ID:', 'trx_socials'),
									'value' => $instance['id'],
									'type' => 'text'));

			$this->show_field(array('name' => 'class',
									'title' => __('Element CSS class:', 'trx_socials'),
									'value' => $instance['class'],
									'type' => 'text'));
		}

		// Show slider params
		function show_fields_slider_param($instance, $group=false, $add_params=array()) {
			if ($group===false)
				$group = __('Slider', 'trx_socials');
			if (!empty($group))
				$this->show_field(array('title' => $group,
										'type' => 'info'));
			
			$this->show_field(array('name' => 'slider',
									'title' => '',
									'label' => __('Slider', 'trx_socials'),
									'value' => (int) $instance['slider'],
									'type' => 'checkbox'));

			$this->show_field(array('name' => 'slides_space',
									'title' => __('Space between slides:', 'trx_socials'),
									'value' => (int) $instance['slides_space'],
									'type' => 'text'));

			$this->show_field(array('name' => 'slider_controls',
									'title' => __('Slider controls:', 'trx_socials'),
									'value' => $instance['slider_controls'],
									'options' => trx_socials_get_list_sc_slider_controls(),
									'type' => 'switch'));

			$this->show_field(array('name' => 'slider_pagination',
									'title' => __('Slider pagination:', 'trx_socials'),
									'value' => $instance['slider_pagination'],
									'options' => trx_socials_get_list_sc_slider_paginations(),
									'type' => 'switch'));

			// Additional params
			if (is_array($add_params) && count($add_params) > 0) {
				foreach ($add_params as $v)
					$this->show_field($v);
			}
		}
		
		// Show title params
		function show_fields_title_param($instance, $group=false, $button=true) {
			if ($group===false)
				$group = __('Titles', 'trx_socials');
			if (!empty($group))
				$this->show_field(array('title' => $group,
										'type' => 'info'));
			
			$this->show_field(array('name' => 'title_style',
									'title' => __('Title style:', 'trx_socials'),
									'value' => $instance['title_style'],
									'options' => apply_filters('trx_socials_sc_type', trx_socials_components_get_allowed_layouts('sc', 'title'), 'trx_sc_title' ),
									'type' => 'switch'));

			$this->show_field(array('name' => 'title_tag',
									'title' => __('Title tag:', 'trx_socials'),
									'value' => $instance['title_tag'],
									'options' => trx_socials_get_list_sc_title_tags(),
									'type' => 'select'));

			$this->show_field(array('name' => 'title_align',
									'title' => __('Title alignment:', 'trx_socials'),
									'value' => $instance['title_align'],
									'options' => trx_socials_get_list_sc_aligns(),
									'type' => 'switch'));

			$this->show_field(array('name' => 'title',
									'title' => __('Title:', 'trx_socials'),
									'value' => $instance['title'],
									'type' => 'text'));

			$this->show_field(array('name' => 'subtitle',
									'title' => __('Subtitle:', 'trx_socials'),
									'value' => $instance['subtitle'],
									'type' => 'text'));

			$this->show_field(array('name' => 'description',
									'title' => __('Description:', 'trx_socials'),
									'value' => $instance['description'],
									'type' => 'textarea'));
			
			// Add button's params
			if ($button) {
				$this->show_field(array('name' => 'link',
										'title' => __('Button URL:', 'trx_socials'),
										'value' => $instance['link'],
										'type' => 'text'));
				$this->show_field(array('name' => 'link_text',
										'title' => __('Button text:', 'trx_socials'),
										'value' => $instance['link_text'],
										'type' => 'text'));
				$this->show_field(array('name' => 'link_style',
										'title' => __('Button style:', 'trx_socials'),
										'value' => $instance['link_style'],
										'options' => apply_filters('trx_socials_sc_type', trx_socials_components_get_allowed_layouts('sc', 'button'), 'trx_sc_button'),
										'type' => 'select'));
				$this->show_field(array('name' => 'link_image',
										'title' => __('Background image for the button:', 'trx_socials'),
										'value' => $instance['link_image'],
										'type' => 'image'));
			}
		}
		
		// Show query params
		function show_fields_query_param($instance, $group=false, $add_params=array()) {
			if ($group===false)
				$group = __('Query', 'trx_socials');
			if (!empty($group))
				$this->show_field(array('title' => $group,
										'type' => 'info'));

			$this->show_field(array('name' => 'ids',
									'title' => __('IDs to show (comma-separated list):', 'trx_socials'),
									'value' => $instance['ids'],
									'type' => 'text'));

			$this->show_field(array('name' => 'count',
									'title' => __('Count:', 'trx_socials'),
									'value' => (int) $instance['count'],
									'type' => 'text'));

			$this->show_field(array('name' => 'columns',
									'title' => __('Columns:', 'trx_socials'),
									'value' => (int) $instance['columns'],
									'type' => 'text'));

			$this->show_field(array('name' => 'offset',
									'title' => __('Offset:', 'trx_socials'),
									'value' => (int) $instance['offset'],
									'type' => 'text'));
	
			$this->show_field(array('name' => 'orderby',
									'title' => __('Order by:', 'trx_socials'),
									'value' => $instance['orderby'],
									'options' => trx_socials_get_list_sc_query_orderby('', 'date,price,title'),
									'type' => 'select'));
	
			$this->show_field(array('name' => 'order',
									'title' => __('Order:', 'trx_socials'),
									'value' => $instance['order'],
									'options' => trx_socials_get_list_sc_query_orders(),
									'type' => 'switch'));
	
			// Additional params
			if (is_array($add_params) && count($add_params) > 0) {
				foreach ($add_params as $v)
					$this->show_field($v);
			}
		}
	
	}
}

require_once TRX_SOCIALS_PLUGIN_DIR_WIDGETS . "instagram/instagram.php"
?>