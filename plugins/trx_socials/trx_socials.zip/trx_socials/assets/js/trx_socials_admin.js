/**
 * Admin utilities (for internal use only!)
 *
 * @package WordPress
 * @subpackage ThemeREX Socials
 * @since v1.0.0
 */

/* global jQuery:false */
/* global TRX_SOCIALS_STORAGE:false */

(function() {

	"use strict";

	if (typeof TRX_SOCIALS_STORAGE == 'undefined') window.TRX_SOCIALS_STORAGE = {};
	
})();