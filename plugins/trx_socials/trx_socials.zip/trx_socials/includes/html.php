<?php
/**
 * HTML & CSS utilities
 *
 * @package WordPress
 * @subpackage ThemeREX Socials
 * @since v1.0.0
 */

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) die( '-1' );

// Output string with the html layout (if not empty)
// (put it between 'before' and 'after' tags)
// Attention! This string may contain layout formed in any plugin (widgets or shortcodes output) and not require escaping to prevent damage!
if ( !function_exists('trx_socials_show_layout') ) {
	function trx_socials_show_layout($str, $before='', $after='') {
		if (trim($str) != '') {
			printf("%s%s%s", $before, $str, $after);
		}
	}
}

// Return value for the style attr
if (!function_exists('trx_socials_prepare_css_value')) {
	function trx_socials_prepare_css_value($val) {
		if ($val != '') {
			$ed = substr($val, -1);
			if ('0'<=$ed && $ed<='9') $val .= 'px';
		}
		return $val;
	}
}


// Add dynamic CSS and return class for it
if (!function_exists('trx_socials_add_inline_css_class')) {
	function trx_socials_add_inline_css_class($css, $suffix='') {
		$class_name = sprintf('trx_socials_inline_%d', mt_rand());
		global $TRX_SOCIALS_STORAGE;
		$TRX_SOCIALS_STORAGE['inline_css'] = (!empty($TRX_SOCIALS_STORAGE['inline_css']) ? $TRX_SOCIALS_STORAGE['inline_css'] : '') 
											. sprintf('.%s%s{%s}', $class_name, !empty($suffix) ? (substr($suffix, 0, 1) != ':' ? ' ' : '') . esc_attr($suffix) : '', $css);
		return $class_name;
	}
}

// Add dynamic CSS to insert it to the footer
if ( !function_exists('trx_socials_add_inline_css') ) {
	function trx_socials_add_inline_css($css) {
		global $TRX_SOCIALS_STORAGE;
		$TRX_SOCIALS_STORAGE['inline_css'] = (!empty($TRX_SOCIALS_STORAGE['inline_css']) ? $TRX_SOCIALS_STORAGE['inline_css'] : '') 
											. $css;
	}
}

// Return dynamic CSS to insert it to the footer
if ( !function_exists('trx_socials_get_inline_css') ) {
	function trx_socials_get_inline_css($clear=false) {
		global $TRX_SOCIALS_STORAGE;
		$rez = '';
        if (!empty($TRX_SOCIALS_STORAGE['inline_css'])) {
        	$rez = $TRX_SOCIALS_STORAGE['inline_css'];
        	if ($clear) $TRX_SOCIALS_STORAGE['inline_css'] = '';
        }
        return $rez;
	}
}

// Add dynamic HTML to insert it to the footer
if ( !function_exists('trx_socials_add_inline_html') ) {
	function trx_socials_add_inline_html($html) {
		global $TRX_SOCIALS_STORAGE;
		$TRX_SOCIALS_STORAGE['inline_html'] = (!empty($TRX_SOCIALS_STORAGE['inline_html']) ? $TRX_SOCIALS_STORAGE['inline_html'] : '')
											. $html;
	}
}

// Return dynamic HTML to insert it to the footer
if ( !function_exists('trx_socials_get_inline_html') ) {
	function trx_socials_get_inline_html() {
		global $TRX_SOCIALS_STORAGE;
		return !empty($TRX_SOCIALS_STORAGE['inline_html']) ? $TRX_SOCIALS_STORAGE['inline_html'] : '';
	}
}


// Return current site protocol
if (!function_exists('trx_socials_get_protocol')) {
	function trx_socials_get_protocol() {
		return is_ssl() ? 'https' : 'http';
	}
}

// Return url without protocol
if (!function_exists('trx_socials_remove_protocol')) {
	function trx_socials_remove_protocol($url, $complete=false) {
		$url = preg_replace('/http[s]?:'.($complete ? '\\/\\/' : '').'/', '', $url);
		return $url;
	}
}

// Check if string is URL
if (!function_exists('trx_socials_is_url')) {
	function trx_socials_is_url($url) {
		return strpos($url, '://')!==false;
	}
}

// Add parameters to URL
if (!function_exists('trx_socials_add_to_url')) {
	function trx_socials_add_to_url($url, $prm) {
		if (is_array($prm) && count($prm) > 0) {
			$separator = strpos($url, '?')===false ? '?' : '&';
			foreach ($prm as $k=>$v) {
				$url .= $separator . urlencode($k) . '=' . urlencode($v);
				$separator = '&';
			}
		}
		return $url;
	}
}
