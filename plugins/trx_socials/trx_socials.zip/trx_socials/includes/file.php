<?php
/**
 * Filesystem utilities
 *
 * @package WordPress
 * @subpackage ThemeREX Socials
 * @since v1.0.0
 */

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) die( '-1' );


/* Check if file/folder present in the child theme and return path (url) to it. 
   Else - path (url) to file in the main theme dir
------------------------------------------------------------------------------------- */
if (!function_exists('trx_socials_get_file_dir')) {	
	function trx_socials_get_file_dir($file, $return_url=false) {
		if ($file[0]=='/') $file = substr($file, 1);
		$theme_dir = get_template_directory().'/'.TRX_SOCIALS_PLUGIN_BASE.'/';
		$theme_url = get_template_directory_uri().'/'.TRX_SOCIALS_PLUGIN_BASE.'/';
		$child_dir = get_stylesheet_directory().'/'.TRX_SOCIALS_PLUGIN_BASE.'/';
		$child_url = get_stylesheet_directory_uri().'/'.TRX_SOCIALS_PLUGIN_BASE.'/';
		$dir = '';
		if (file_exists(($child_dir).($file)))
			$dir = ($return_url ? $child_url : $child_dir) . ($file);
		else if (file_exists(($theme_dir).($file)))
			$dir = ($return_url ? $theme_url : $theme_dir) . ($file);
		else if (file_exists(TRX_SOCIALS_PLUGIN_DIR . ($file)))
			$dir = ($return_url ? TRX_SOCIALS_PLUGIN_URL : TRX_SOCIALS_PLUGIN_DIR) . ($file);
		return apply_filters( $return_url ? 'trx_socials_get_file_url' : 'trx_socials_get_file_dir', $dir, $file );
	}
}

if (!function_exists('trx_socials_get_file_url')) {	
	function trx_socials_get_file_url($file) {
		return trx_socials_get_file_dir($file, true);
	}
}

// Get text from specified file via HTTP (cURL)
if (!function_exists('trx_socials_remote_get')) {	
	function trx_socials_remote_get($file, $timeout=-1) {
		// Set timeout as half of the PHP execution time
		if ($timeout < 1) $timeout = round( 0.5 * max(30, ini_get('max_execution_time')));
		$response = wp_remote_get($file, array(
									'method'  => 'GET',
									'timeout' => $timeout
									)
								);
		//return wp_remote_retrieve_response_code( $response ) == 200 ? wp_remote_retrieve_body( $response ) : '';
		return !is_wp_error($response) && isset($response['response']['code']) && $response['response']['code']==200 ? $response['body'] : '';
	}
}

// Get text from specified file via HTTP (cURL)
if (!function_exists('trx_socials_remote_post')) {	
	function trx_socials_remote_post($file, $args, $timeout=-1) {
		// Set timeout as half of the PHP execution time
		if ($timeout < 1) $timeout = round( 0.5 * max(30, ini_get('max_execution_time')));
		$response = wp_remote_post($file, array(
									'method'  => 'POST',
									'timeout' => $timeout,
									'body'    => $args
									)
								);
		//return wp_remote_retrieve_response_code( $response ) == 200 ? wp_remote_retrieve_body( $response ) : '';
		return !is_wp_error($response) && isset($response['response']['code']) && $response['response']['code']==200 ? $response['body'] : '';
	}
}


// Include part of template with specified parameters
if (!function_exists('trx_socials_get_template_part')) {	
	function trx_socials_get_template_part($file, $args_name='', $args=array()) {
		static $fdirs = array();
		if (!is_array($file))
			$file = array($file);
		foreach ($file as $f) {
			if (!empty($fdirs[$f]) || ($fdirs[$f] = trx_socials_get_file_dir($f)) != '') { 
				if (!empty($args_name) && !empty($args))
					set_query_var($args_name, $args);
				include $fdirs[$f];
				break;
			}
		}
	}
}
