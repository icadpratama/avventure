<?php
/**
 * Media utilities
 *
 * @package WordPress
 * @subpackage ThemeREX Socials
 * @since v1.0.0
 */

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) die( '-1' );


// Get image sizes from image url (if image in the uploads folder)
if (!function_exists('trx_socials_getimagesize')) {
	function trx_socials_getimagesize($url, $echo=false) {
		// Remove scheme from url
		$url = trx_socials_remove_protocol($url);
	
		// Get upload path & dir
		$upload_info = wp_upload_dir();

		// Where check file
		$locations = array(
			'uploads' => array(
				'dir' => $upload_info['basedir'],
				'url' => trx_socials_remove_protocol($upload_info['baseurl'])
				),
			'child' => array(
				'dir' => get_stylesheet_directory(),
				'url' => trx_socials_remove_protocol(get_stylesheet_directory_uri())
				),
			'theme' => array(
				'dir' => get_template_directory(),
				'url' => trx_socials_remove_protocol(get_template_directory_uri())
				)
			);
		
		$img_size = false;
		
		foreach($locations as $key=>$loc) {
			// Check if $img_url is local.
			if ( false === strpos($url, $loc['url']) ) continue;
			
			// Get path of image.
			$img_path = str_replace($loc['url'], $loc['dir'], $url);
		
			// Check if img path exists, and is an image indeed.
			if ( !file_exists($img_path)) continue;
	
			// Get image size
			$img_size = getimagesize($img_path);
			break;
		}
		
		if ($echo && $img_size!==false && !empty($img_size[3])) {
			echo ' '.trim($img_size[3]);
		}
		
		return $img_size;
	}
}

// Return image size name with @retina modifier (if need)
if (!function_exists('trx_socials_get_thumb_size')) {
	function trx_socials_get_thumb_size($ts) {
		$retina = trx_socials_get_retina_multiplier() > 1 ? '-@retina' : '';
		return apply_filters('trx_socials_filter_get_thumb_size', ($ts=='post-thumbnail' || strpos($ts, 'trx_socials-thumb-')===0 ? '' : 'trx_socials-thumb-') . $ts . $retina);
	}
}

// Clear thumb sizes from image name
if (!function_exists('trx_socials_clear_thumb_size')) {
	function trx_socials_clear_thumb_size($url) {
		$pi = pathinfo($url);
		$pi['dirname'] = trx_socials_remove_protocol($pi['dirname']);
		$parts = explode('-', $pi['filename']);
		$suff = explode('x', $parts[count($parts)-1]);
		if (count($suff)==2 && (int) $suff[0] > 0 && (int) $suff[1] > 0) {
			array_pop($parts);
			$url = $pi['dirname'] . '/' . join('-', $parts) . '.' . $pi['extension'];
		}
		return $url;
	}
}

// Add thumb sizes to image name
if (!function_exists('trx_socials_add_thumb_size')) {
	function trx_socials_add_thumb_size($url, $thumb_size, $check_exists=true) {
		
		if (empty($url)) return '';

		$pi = pathinfo($url);
		$pi['dirname'] = trx_socials_remove_protocol($pi['dirname']);

		// Remove image sizes from filename
		$parts = explode('-', $pi['filename']);
		$suff = explode('x', $parts[count($parts)-1]);
		if (count($suff)==2 && (int) $suff[0] > 0 && (int) $suff[1] > 0) {
			array_pop($parts);
		}
		$url = $pi['dirname'] . '/' . join('-', $parts) . '.' . $pi['extension'];

		// Add new image sizes
		global $_wp_additional_image_sizes;
		if ( isset( $_wp_additional_image_sizes ) && count( $_wp_additional_image_sizes ) && in_array( $thumb_size, array_keys( $_wp_additional_image_sizes ) ) )
			$parts[] = intval( $_wp_additional_image_sizes[$thumb_size]['width'] ) . 'x' . intval( $_wp_additional_image_sizes[$thumb_size]['height'] );
		$pi['filename'] = join('-', $parts);
		$new_url = $pi['dirname'] . '/' . $pi['filename'] . '.' . $pi['extension'];

		// Check exists
		if ($check_exists) {
			$uploads_info = wp_upload_dir();
			$uploads_url = trx_socials_remove_protocol($uploads_info['baseurl']);
			$uploads_dir = $uploads_info['basedir'];
			if (strpos($new_url, $uploads_url)!==false) {
				if (!file_exists(str_replace($uploads_url, $uploads_dir, $new_url)))
					$new_url = $url;
			} else {
				$new_url = $url;
			}
		}
		return $new_url;
	}
}

// Return thumb dimensions by thumb size name
if (!function_exists('trx_socials_get_thumb_dimensions')) {
	function trx_socials_get_thumb_dimensions($thumb_size) {
		$dim = array('width' => 0, 'height' => 0);
		global $_wp_additional_image_sizes;
		if ( isset( $_wp_additional_image_sizes ) && count( $_wp_additional_image_sizes ) && in_array( $thumb_size, array_keys( $_wp_additional_image_sizes ) ) ) {
			$dim['width']  = intval( $_wp_additional_image_sizes[$thumb_size]['width'] );
			$dim['height'] = intval( $_wp_additional_image_sizes[$thumb_size]['height'] );
		}
		return $dim;
	}
}

// Return image size multiplier
if (!function_exists('trx_socials_get_retina_multiplier')) {
	function trx_socials_get_retina_multiplier($force_retina=0) {
		return 1;
	}
}

// Return 'no-image'
if (!function_exists('trx_socials_get_no_image')) {
	function trx_socials_get_no_image($img='css/images/no-image.jpg') {
		return apply_filters('trx_socials_filter_no_image', trx_socials_get_file_url($img));
	}
}


// Return video player layout
if (!function_exists('trx_socials_get_video_layout')) {
	function trx_socials_get_video_layout($args=array()) {
		$args = array_merge(array(
			'link' => '',					// Link to the video on Youtube or Vimeo
			'embed' => '',					// Embed code instead link
			'cover' => '',					// URL or ID of the cover image
			'show_cover' => true,			// Show cover image or only add classes
			'popup' => false,				// Open video in the popup window or insert instead cover image (default)
			'class' => '',					// Additional classes for slider container
			'id' => ''						// ID of the slider container
			), $args);

		if (empty($args['embed']) && empty($args['link'])) return '';
		if (empty($args['cover'])) $args['popup'] = false;
		if (empty($args['id'])) $args['id'] = 'sc_video_'.str_replace('.', '',mt_rand());
		
		$output = '<div id="'.esc_attr($args['id']).'"'
					. ' class="trx_socials_video_player' 
								. (!empty($args['cover']) ? ' with_cover hover_play' : ' without_cover')
								. (!empty($args['class']) ? ' ' . esc_attr($args['class']) : '')
							. '"'
					. '>';
		$args['embed'] = trx_socials_get_embed_layout(array(
														'link' => $args['link'],
														'embed' => $args['embed']
													));
		if (!empty($args['cover'])) {
			$args['cover'] = trx_socials_get_attachment_url($args['cover'], 
										apply_filters('trx_socials_filter_video_cover_thumb_size', trx_socials_get_thumb_size('huge')));
			if (!empty($args['cover'])) {
				if (empty($args['popup']))
					$args['embed'] = trx_socials_make_video_autoplay($args['embed']);
				if ($args['show_cover']) {
					$attr = trx_socials_getimagesize($args['cover']);
					$output .= '<img src="' . esc_url($args['cover']) . '" alt="' . esc_attr__("Video cover", 'trx_socials') . '"' . (!empty($attr[3]) ? ' '.trim($attr[3]) : '').'>';
				}
				$output .= apply_filters('trx_socials_filter_video_mask',
								'<div class="video_mask"></div>'
								. ($args['popup']
										? '<a class="video_hover trx_socials_popup_link" href="#'.esc_attr($args['id']).'_popup"></a>'
										: '<div class="video_hover" data-video="'.esc_attr($args['embed']).'"></div>'
								),
								$args);
			}
		}
		if (empty($args['popup'])) {
			$output .= '<div class="video_embed video_frame">'
							. (empty($args['cover']) ? $args['embed'] : '')
						. '</div>';
		}
		$output .= '</div>';
		// Add popup
		if (!empty($args['popup'])) {
			// Attention! Don't remove comment <!-- .sc_layouts_popup --> - it used to split output on parts in the sc_promo
			$output .= '<!-- .sc_layouts_popup --><div id="'.esc_attr($args['id']).'_popup" class="sc_layouts_popup">'
						. '<div id="'.esc_attr($args['id']).'_popup_player"'
							. ' class="trx_socials_video_player without_cover'
										. (!empty($args['class']) ? ' ' . esc_attr($args['class']) : '')
									. '"'
							. '>'
								. '<div class="video_embed video_frame">'
									. str_replace(array('wp-video'), 'trx_socials_video', $args['embed'])
								. '</div>'
							. '</div>'
						. '</div>';
		}
		return apply_filters('trx_socials_filter_video_layout', $output, $args);
	}
}


// Return embeded code layout
if (!function_exists('trx_socials_get_embed_layout')) {
	function trx_socials_get_embed_layout($args=array()) {
		$args = array_merge(array(
			'link' => '',					// Link to the video on Youtube or Vimeo
			'embed' => ''					// Embed code instead link
			), $args);

		if (empty($args['embed']) && empty($args['link'])) return '';
		if (!empty($args['embed'])) {
			$args['embed'] = str_replace("`", '"', $args['embed']);
		} else {
			global $wp_embed;
			if (is_object($wp_embed))
				$args['embed'] = do_shortcode($wp_embed->run_shortcode( sprintf('[embed]%s[/embed]', $args['link']) ));
		}
		return apply_filters('trx_socials_filter_embed_layout', $args['embed'], $args);
	}
}



// Return image url by attachment ID
if (!function_exists('trx_socials_get_attachment_url')) {
	function trx_socials_get_attachment_url($image_id, $size='full') {
		if ($image_id > 0) {
			$attach = wp_get_attachment_image_src($image_id, $size);
			$image_id = isset($attach[0]) && $attach[0]!='' ? $attach[0] : '';
		} else
			$image_id = trx_socials_add_thumb_size($image_id, $size);
		return $image_id;
	}
}


// Add 'autoplay' feature in the video
if (!function_exists('trx_socials_make_video_autoplay')) {
	function trx_socials_make_video_autoplay($video) {
		if (($pos = strpos($video, '<video'))!==false) {
			$video = str_replace('<video', '<video autoplay="autoplay"', $video);
		} else if (($pos = strpos($video, '<iframe'))!==false) {
			if (preg_match('/(<iframe.+src=[\'"])([^\'"]+)([\'"][^>]*>)(.*)/i', $video, $matches)) {
				$video = $matches[1] . $matches[2] . (strpos($matches[2], '?')!==false ? '&' : '?') . 'autoplay=1' . $matches[3] . $matches[4];
			}
		}
		return $video;
	}
}
