<?php


include WPIM_DIR . 'includes/helpers.php';

// Make WPIM\WPIM as WPIM alias.
class_alias( 'WPIM\\WPIM', 'WPIM' );