<?php
/**
 * Template part for displaying content paragraph
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WPIM
 * @since 1.0
 * @version 1.0
 */
echo wpautop($infowindow->get_content());